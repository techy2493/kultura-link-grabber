# kultura-link-grabber
An extension to generate a link from Occupy White Wall's Kultura site to be pasted in game chat.


# How to build
The following applications / command line interfaces are required to run this program
nodejs
npm
gulp-cli

To build this script run the following commands

- npm install
- gulp build