function act(link) {
    alert(link)
}